"use client";

import { useEffect, useMemo, useRef, useState } from "react";

type Role = "user" | "assistant";
type Msg = { role: Role; text: string };

const EXAMPLE_PROMPTS = [
  "Solve and verify: x³ - 6x² + 11x - 6 = 0",
  "Derive the time-independent Schrödinger equation for a particle in a box.",
  "Simulate a Bell state circuit and verify expected correlations.",
  "Summarize recent papers on Variational Quantum Algorithms.",
];

export default function HomePage() {
  const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
  const [conversationId, setConversationId] = useState<string>("");
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState<Msg[]>([]);
  const [sending, setSending] = useState(false);
  const [status, setStatus] = useState<"Ready" | "Working...">("Ready");
  const endRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const existing = localStorage.getItem("conversation_id");
    const cid = existing ?? crypto.randomUUID();
    localStorage.setItem("conversation_id", cid);
    setConversationId(cid);
    setMessages([
      {
        role: "assistant",
        text: "Hi! I am QuantumMathResearchGPT — your scientific copilot.\n\nAsk for a derivation, quantum explanation, symbolic simplification, or a simulation.",
      },
    ]);
  }, []);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, sending]);

  const canSend = useMemo(
    () => input.trim().length > 0 && !sending,
    [input, sending]
  );

  async function sendMessage(overrideText?: string) {
    const userMessage = (overrideText ?? input).trim();
    if (!userMessage || sending) return;

    setMessages((prev) => [...prev, { role: "user", text: userMessage }]);
    setInput("");
    setSending(true);
    setStatus("Working...");

    try {
      const res = await fetch(`${API_URL}/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          user_message: userMessage,
          conversation_id: conversationId,
        }),
      });

      if (!res.ok) {
        const t = await res.text().catch(() => "");
        throw new Error(`HTTP ${res.status}: ${t || res.statusText}`);
      }

      const data = await res.json();
      setMessages((prev) => [
        ...prev,
        { role: "assistant", text: data?.answer ?? "(no answer)" },
      ]);
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : String(e);
      setMessages((prev) => [
        ...prev,
        { role: "assistant", text: `Error: ${msg}` },
      ]);
    } finally {
      setSending(false);
      setStatus("Ready");
    }
  }

  function resetConversation() {
    const cid = crypto.randomUUID();
    localStorage.setItem("conversation_id", cid);
    setConversationId(cid);
    setMessages([
      {
        role: "assistant",
        text: "New conversation started. What would you like to explore?",
      },
    ]);
  }

  return (
    <div className="min-h-screen bg-[radial-gradient(900px_600px_at_10%_10%,rgba(110,168,254,0.22),transparent_55%),radial-gradient(900px_600px_at_90%_30%,rgba(155,93,255,0.18),transparent_50%)] bg-[#0b1020] text-white">
      <div className="mx-auto max-w-3xl px-4 py-8">
        {/* Header */}
        <header className="mb-6 flex items-start justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold tracking-wide">
              QuantumMathResearchGPT
            </h1>
            <p className="mt-1 text-sm text-white/60">
              Mathematics · Quantum Physics · Symbolic Computation · Research
            </p>
          </div>
          <div className="flex items-center gap-2 text-xs text-white/60">
            <span className="rounded-md border border-white/15 bg-white/5 px-2 py-1 font-mono">
              Enter
            </span>{" "}
            send ·{" "}
            <span className="rounded-md border border-white/15 bg-white/5 px-2 py-1 font-mono">
              Shift+Enter
            </span>{" "}
            newline
          </div>
        </header>

        {/* Chat panel */}
        <section className="rounded-2xl border border-white/15 bg-white/5 shadow-[0_14px_40px_rgba(0,0,0,0.35)] overflow-hidden">
          {/* Top bar */}
          <div className="flex items-center justify-between border-b border-white/15 px-4 py-3">
            <div className="flex items-center gap-2">
              <span
                className={`h-2 w-2 rounded-full ${sending ? "bg-yellow-400" : "bg-green-400"}`}
              />
              <span className="text-xs text-white/60">{status}</span>
            </div>
            <button
              onClick={resetConversation}
              className="rounded-md border border-white/15 bg-white/5 px-3 py-1 text-xs text-white/60 hover:bg-white/10 transition-colors"
            >
              New conversation
            </button>
          </div>

          {/* Messages */}
          <div className="h-[60vh] min-h-[480px] overflow-auto px-4 py-4 space-y-3">
            {messages.map((m, idx) => (
              <div
                key={idx}
                className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}
              >
                <div
                  className={`max-w-[85%] whitespace-pre-wrap rounded-2xl border px-4 py-3 text-sm leading-relaxed ${
                    m.role === "user"
                      ? "border-blue-300/25 bg-blue-400/10"
                      : "border-white/10 bg-white/5"
                  }`}
                >
                  {m.text}
                </div>
              </div>
            ))}
            {sending && (
              <div className="flex justify-start">
                <div className="rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white/50">
                  Thinking...
                </div>
              </div>
            )}
            <div ref={endRef} />
          </div>

          {/* Example prompts */}
          {messages.length <= 1 && (
            <div className="border-t border-white/10 px-4 py-3 flex flex-wrap gap-2">
              {EXAMPLE_PROMPTS.map((p, i) => (
                <button
                  key={i}
                  onClick={() => sendMessage(p)}
                  className="rounded-xl border border-white/15 bg-white/5 px-3 py-2 text-xs text-white/70 hover:bg-white/10 transition-colors text-left"
                >
                  {p}
                </button>
              ))}
            </div>
          )}

          {/* Input */}
          <div className="border-t border-white/15 p-4 grid grid-cols-1 md:grid-cols-[1fr_auto] gap-3 items-end">
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              disabled={sending}
              rows={2}
              placeholder="Derive, verify, simplify, or simulate..."
              className="w-full resize-none rounded-xl border border-white/15 bg-white/5 px-4 py-3 text-sm outline-none focus:border-blue-300/40 focus:shadow-[0_0_0_4px_rgba(110,168,254,0.14)] transition-all"
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  void sendMessage();
                }
              }}
            />
            <button
              onClick={() => void sendMessage()}
              disabled={!canSend}
              className="rounded-xl bg-blue-500 px-5 py-3 font-semibold text-white disabled:opacity-40 disabled:cursor-not-allowed hover:bg-blue-400 transition-colors"
            >
              {sending ? "Sending..." : "Send"}
            </button>
          </div>
        </section>

        {/* Footer */}
        <footer className="mt-4 text-center text-xs text-white/30">
          QuantumMathResearchGPT · FastAPI + Anthropic tool calling · Next.js + Tailwind
        </footer>
      </div>
    </div>
  );
}
