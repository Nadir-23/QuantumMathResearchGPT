import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "QuantumMathResearchGPT",
  description:
    "A multi-agent scientific AI assistant for Mathematics, Quantum Physics, Symbolic Computation, Numerical Simulation, and Research Assistance.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
