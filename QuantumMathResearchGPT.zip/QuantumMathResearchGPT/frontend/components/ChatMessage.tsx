import React from "react";

type Role = "user" | "assistant";

interface ChatMessageProps {
  role: Role;
  text: string;
}

export function ChatMessage({ role, text }: ChatMessageProps) {
  return (
    <div className={`flex ${role === "user" ? "justify-end" : "justify-start"}`}>
      <div
        className={`max-w-[85%] whitespace-pre-wrap rounded-2xl border px-4 py-3 text-sm leading-relaxed ${
          role === "user"
            ? "border-blue-300/25 bg-blue-400/10"
            : "border-white/10 bg-white/5"
        }`}
      >
        {text}
      </div>
    </div>
  );
}
