# Core orchestration logic
