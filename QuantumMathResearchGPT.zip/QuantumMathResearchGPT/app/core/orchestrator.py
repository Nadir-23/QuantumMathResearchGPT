from __future__ import annotations

import json
import os
from typing import Any, Dict, List, Tuple

from anthropic import Anthropic

from app.core.tool_specs import TOOL_SPECS
from app.core.tools_registry import TOOL_REGISTRY
from app.prompts.system_prompt import SYSTEM_PROMPT

ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")
ANTHROPIC_MODEL = os.getenv("ANTHROPIC_MODEL", "claude-3-5-sonnet-latest")

client = Anthropic(api_key=ANTHROPIC_API_KEY)


def _extract_text(content: Any) -> str:
    out = []
    for b in content or []:
        if getattr(b, "type", None) == "text":
            out.append(getattr(b, "text", ""))
    return "".join(out).strip()


def run_orchestrator(
    conversation_id: str,
    user_message: str,
) -> Tuple[str, Dict[str, Any]]:
    debug: Dict[str, Any] = {
        "conversation_id": conversation_id,
        "tool_calls": [],
    }

    chat_messages: List[Dict[str, Any]] = [
        {"role": "user", "content": user_message},
    ]

    max_rounds = 6
    tool_outputs_summaries: List[str] = []

    for _ in range(max_rounds):
        resp = client.messages.create(
            model=ANTHROPIC_MODEL,
            system=SYSTEM_PROMPT,
            max_tokens=2000,
            messages=chat_messages,
            tools=TOOL_SPECS,
        )

        content = getattr(resp, "content", [])
        tool_calls = [b for b in (content or []) if getattr(b, "type", None) == "tool_use"]

        if not tool_calls:
            final_text = _extract_text(content)
            return (final_text or "(empty response)", debug)

        # Execute tool calls
        for tc in tool_calls:
            name = getattr(tc, "name", None)
            tool_id = getattr(tc, "id", None)
            tool_input = getattr(tc, "input", None) or {}

            fn = TOOL_REGISTRY.get(name)
            if fn is None:
                result = {"error": f"Unknown tool: {name}"}
            else:
                try:
                    result = fn(**tool_input)
                except Exception as e:
                    result = {"error": str(e)}

            debug["tool_calls"].append(
                {
                    "tool_id": tool_id,
                    "name": name,
                    "input": tool_input,
                    "result": result,
                }
            )
            tool_outputs_summaries.append(
                f"{name}({tool_input}) => {json.dumps(result)}"
            )

        # Feed tool outputs back as a user message
        chat_messages.append(
            {
                "role": "user",
                "content": "Tool outputs (use them to answer exactly):\n"
                + "\n".join(tool_outputs_summaries),
            }
        )
        tool_outputs_summaries = []

    return ("Tool-calling loop limit reached without a final answer.", debug)
