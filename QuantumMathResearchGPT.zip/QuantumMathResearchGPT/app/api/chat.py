from fastapi import APIRouter
from pydantic import BaseModel
import uuid

from app.core.orchestrator import run_orchestrator

router = APIRouter()


class ChatRequest(BaseModel):
    user_message: str
    conversation_id: str | None = None


class ChatResponse(BaseModel):
    conversation_id: str
    answer: str
    debug: dict = {}


@router.post("/chat", response_model=ChatResponse)
def chat(req: ChatRequest):
    conversation_id = req.conversation_id or str(uuid.uuid4())
    answer, debug = run_orchestrator(
        conversation_id=conversation_id,
        user_message=req.user_message,
    )
    return ChatResponse(
        conversation_id=conversation_id,
        answer=answer,
        debug=debug,
    )
